#include "packet.h"
#include "CommandMsg.h"

#ifndef __AM_TYPES_H__
#define __AM_TYPES_H__
enum{
    AM_FLOODING=10
};
#endif
